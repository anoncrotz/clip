<?

$UserId = "xxxxxx";
$Token = "xxxxxx";
$Uuid = "xxxxxxx";